---
title: Collector page prototype -- Portal
---

## About

* This is the main collector model, variants are created at the "03-templates" level using local json data files as ~variants.

## Considerations & to-do's

* One
* Two
* Three
